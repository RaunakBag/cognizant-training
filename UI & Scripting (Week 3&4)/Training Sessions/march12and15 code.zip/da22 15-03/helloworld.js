var names = ["Alice", "Bob", "Eve"];
names.forEach(function (s) {
    abc(s);
});
function abc(x) {
    console.log(x.toUpperCase());
}
