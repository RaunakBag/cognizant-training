function add<T,R>(n1: T,n2: R): Array<T|R> {    
    return [n1,n2]
}

var ar = add<number,number>(12,23);

var br = add<string,string>('praveen','manoj');

var cr = add<string,number>('praveen',11);

var dr = add<number,string>(11,'pppp');

var er = add<number,boolean>(11,false);

console.log(ar);
console.log(br);
console.log(br);