var obj = {
    firstname:'praveen',
    lastname:'gubbala',
    age:35
}

interface person{
    firstname:string,
    lastname:string,
    age?:number
}

var ob1:typeof obj={
    firstname:'rahul',
    lastname:'reddy',
    age:33
};

var ob2:person={
    firstname:'venky',
    lastname:'dudu'
}