export default class Human{
    email:string='';
    nationality:string='';
}
export const x = 100;
export const cardetails={
    name:'eon',
    model:'hundai'
}