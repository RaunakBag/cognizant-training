import Human  from './Human'
import { x,cardetails } from './Human';
console.log(x);
console.log(cardetails)

class Person extends Human{
    phonenumber:number=0;
}
class Employee extends Person{
    fullname:string='';
    dob:string='';
    place:string='';
    pincode:number=0;
    gender:string='';
    interest:string='';
    getAge(){
        return this.dob;
    }
}

var emp1 = {
    fullname:'praveen gubbala',
    dob:'11/2/1983',
    place:'hyderabad',
    pincode:445533,
    gender:'male',
    interest:'Javascript'
}

var emp2 = new Employee();
