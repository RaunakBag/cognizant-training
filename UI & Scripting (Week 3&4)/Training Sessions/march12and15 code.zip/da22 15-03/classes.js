"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
exports.__esModule = true;
var Human_1 = require("./Human");
var Human_2 = require("./Human");
console.log(Human_2.x);
console.log(Human_2.cardetails);
var Person = /** @class */ (function (_super) {
    __extends(Person, _super);
    function Person() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.phonenumber = 0;
        return _this;
    }
    return Person;
}(Human_1["default"]));
var Employee = /** @class */ (function (_super) {
    __extends(Employee, _super);
    function Employee() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.fullname = '';
        _this.dob = '';
        _this.place = '';
        _this.pincode = 0;
        _this.gender = '';
        _this.interest = '';
        return _this;
    }
    Employee.prototype.getAge = function () {
        return this.dob;
    };
    return Employee;
}(Person));
var emp1 = {
    fullname: 'praveen gubbala',
    dob: '11/2/1983',
    place: 'hyderabad',
    pincode: 445533,
    gender: 'male',
    interest: 'Javascript'
};
var emp2 = new Employee();
