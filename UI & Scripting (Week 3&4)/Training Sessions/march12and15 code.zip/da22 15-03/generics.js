function add(n1, n2) {
    return [n1, n2];
}
var ar = add(12, 23);
var br = add('praveen', 'manoj');
console.log(ar);
console.log(br);
