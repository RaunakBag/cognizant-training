"use strict";
exports.__esModule = true;
exports.cardetails = exports.x = void 0;
var Human = /** @class */ (function () {
    function Human() {
        this.email = '';
        this.nationality = '';
    }
    return Human;
}());
exports["default"] = Human;
exports.x = 100;
exports.cardetails = {
    name: 'eon',
    model: 'hundai'
};
